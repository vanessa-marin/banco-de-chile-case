# Pitch – Banco de Chile

Pitch de 60–90 segundos para entrevistas.
